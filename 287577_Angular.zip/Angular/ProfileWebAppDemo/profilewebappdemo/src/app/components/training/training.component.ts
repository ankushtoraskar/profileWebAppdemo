import { Component } from '@angular/core';

@Component({
  selector: 'app-training',
  imports: [],
  templateUrl: './training.component.html',
  styleUrl: './training.component.css'
})
export class TrainingComponent {

}
