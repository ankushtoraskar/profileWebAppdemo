import { Component } from '@angular/core';

@Component({
  selector: 'app-achivements',
  imports: [],
  templateUrl: './achivements.component.html',
  styleUrl: './achivements.component.css'
})
export class AchivementsComponent {

}
